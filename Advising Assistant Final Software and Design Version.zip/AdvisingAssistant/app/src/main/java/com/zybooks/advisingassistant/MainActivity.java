/* Advising Assistant is a application to help add, list, and find courses for the school.
*  This app will contain the course ID, the name of the course, and the prerequisite
* for each course.
*
* This app is a recreation of CS 300, DSA: Analysis and Design from SNHU, Advising Assistant Program
* for the final project in CS 499 by Samantha Lasseigne */

package com.zybooks.advisingassistant;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        // This button switches the screen from the MainActivity class to the AddCourse Class
        Button addButton = findViewById(R.id.addCourse);
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this.getBaseContext(), AddCourse.class);
            MainActivity.this.startActivity(intent);
        });

        // This button switches the screen from the MainActivity class to the ListAllCourses Class
        Button viewAllCourses = findViewById(R.id.viewAllCourses);
        viewAllCourses.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this.getBaseContext(), ListCourseNames.class);
            MainActivity.this.startActivity(intent);
        });

        // This button switches the screen from the MainActivity class to the ListSingleCourse Class
        Button viewOneCourse = findViewById(R.id.viewOneCourse);
        viewOneCourse.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this.getBaseContext(), ListSingleCourse.class);
            MainActivity.this.startActivity(intent);
        });
    }

    protected void onPause(){
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
    }
}