package com.zybooks.advisingassistant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class CourseDatabase extends DatabaseConnection{
    public CourseDatabase(Context context) {
        super(context);
    }

    public Course addCourse(String iD, String name, String preR) {
        SQLiteDatabase db = this.getWritableDatabase();

        Course course = new Course();
        course.set_courseId(iD);
        course.set_name(name);
        course.set_preReq(preR);

        ContentValues values = course.getContentValuesToAdd();
        Long id = db.insert("courseList", null,values);
        db.close();

        course.setiD(id.intValue());

        return course;
    }
    public List<Course> getList() {
        List<Course> courses = new ArrayList<>();

        String selectQuery = "SELECT * FROM courseList";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Course course = new Course();
                course.parse(cursor);
                courses.add(course);
            } while (cursor.moveToNext());
        }
        db.close();
        return courses;
    }
}
