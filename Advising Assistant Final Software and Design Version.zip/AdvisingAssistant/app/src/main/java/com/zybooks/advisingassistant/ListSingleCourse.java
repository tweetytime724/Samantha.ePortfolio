package com.zybooks.advisingassistant;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Objects;

public class ListSingleCourse extends AppCompatActivity {

    BinaryTreeClass binaryTreeClass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.list_single_course);

        EditText idForSearch = findViewById(R.id.searchID);
        EditText idDisplay = findViewById(R.id.courseIDdisplay);
        EditText nameDisplay = findViewById(R.id.courseNameDisplay);
        EditText preReqDisplay = findViewById(R.id.coursePrereqDisplay);

        // This button returns from current page to MainActivity class
        Button backButton = findViewById(R.id.back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListSingleCourse.this.getBaseContext(), MainActivity.class);
                ListSingleCourse.this.startActivity(intent);
            }
        });

        // This method will call for a specific course from the tree and add the information onto
        // the correct lines.
        Button search = findViewById(R.id.search);
        search.setOnClickListener(view -> {

            String id = idForSearch.getText().toString();

            ArrayList<Course> foundCourse = BinaryTreeClass.getOneCourse(id);

            if (foundCourse != null) {
                idDisplay.setText(foundCourse.get(0).getCourseId());
                nameDisplay.setText(foundCourse.get(0).getName());
                preReqDisplay.setText(foundCourse.get(0).get_preReq());
                idForSearch.setText("");
                foundCourse.clear();
            }
            else {
                Toast.makeText(ListSingleCourse.this, "Course not found", Toast.LENGTH_SHORT).show();
            }

        });

    }
    protected void onPause(){
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
    }
}