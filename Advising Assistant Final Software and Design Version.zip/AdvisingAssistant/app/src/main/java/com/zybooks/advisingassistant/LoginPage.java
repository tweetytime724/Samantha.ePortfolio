package com.zybooks.advisingassistant;

import static android.app.ProgressDialog.show;
import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class LoginPage extends AppCompatActivity {

    ConcurrentHashMap<String, String> credentials = new ConcurrentHashMap<>();
    static ConcurrentHashMap<String, byte[]> hashStorage = new ConcurrentHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        EditText username = findViewById(R.id.usernameInput);
        EditText password = findViewById(R.id.passwordInput);
        EditText newUser = findViewById(R.id.newUserName);
        EditText newPassword= findViewById(R.id.newPassword);
        Button newUserClick = findViewById(R.id.newUserButton);
        Button submit = findViewById(R.id.SignIn);
        Button createUser = findViewById(R.id.createUser);
        Button returnToLogin = findViewById(R.id.returnToSignIn);

        submit.setOnClickListener(v -> {
            String userInput = username.getText().toString();
            String passwordInput = password.getText().toString();

            /*try {
                passwordInput = hashVerify(userInput, passwordInput);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }*/

            if(verifyPassword(userInput, passwordInput)) {
                Toast.makeText(this, "welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginPage.this.getBaseContext(), MainActivity.class);
                LoginPage.this.startActivity(intent);
                }
            else {
                Toast.makeText(this, "Error: Username does not exists", Toast.LENGTH_SHORT).show();
            }

        });

        /* This button will switch everything from viewing the sign in components to new user components*/
        newUserClick.setOnClickListener(view -> {
            username.setVisibility(INVISIBLE);
            password.setVisibility(INVISIBLE);
            submit.setVisibility(INVISIBLE);
            newUser.setVisibility(VISIBLE);
            newPassword.setVisibility(VISIBLE);
            createUser.setVisibility(VISIBLE);
            newUserClick.setVisibility(INVISIBLE);
            returnToLogin.setVisibility(VISIBLE);
        });

        /* This button will switch everything from the new user components to the sign in components*/
        returnToLogin.setOnClickListener(view -> {
            username.setVisibility(VISIBLE);
            password.setVisibility(VISIBLE);
            submit.setVisibility(VISIBLE);
            newUser.setVisibility(INVISIBLE);
            newPassword.setVisibility(INVISIBLE);
            createUser.setVisibility(INVISIBLE);
            newUserClick.setVisibility(VISIBLE);
            returnToLogin.setVisibility(INVISIBLE);
        });

        createUser.setOnClickListener(view -> {
            String newUsername = newUser.getText().toString();
            String newPasscode = newPassword.getText().toString();

           /* try {
                newPasscode = hashPassword(newUsername,newPasscode);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }*/

            addUser(newUsername, newPasscode);
            newUser.setText("");
            newPassword.setText("");
        });
    }

    public void addUser(String username, String password) {
        Log.d("added", "make it to method addUser");
        credentials.put(username, password);
        Log.d("added", "added user " + credentials.get(username));
        Toast.makeText(this, "username and password accepted", Toast.LENGTH_SHORT).show();
    }

    public boolean verifyPassword(String username, String password) {
        Log.d("password", "verified password");
        Log.d("user/pass", "user/pass" + credentials.get(username));
        if (credentials.get(username).equals(password)){
            return true;
        }
        return false;
    }
    /* For this security measure of hashing a password to keep information safe I am using PBKDF2 -
     * Password-Based key derivation function 2. My main plan was to use BCrypt but it is not fully
     * in Java yet and SHA-512, which I used before is not recommended due to vulnerabilities.*/

    /*public static String hashPassword(String user, String password) throws Exception {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);

        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65636, 256);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2Hash");

        byte[] hash = keyFactory.generateSecret(spec).getEncoded();
        String hashString = Arrays.toString(hash);
        hashStorage.put(user, hash);
        Log.d("hashed", "password hashed" + hashString);
        return Base64.getEncoder().encodeToString(hash);
    }

    public static String hashVerify(String user, String password) throws Exception {
        byte[] salt = hashStorage.get(user);
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65636, 256);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2Hash");

        byte[] hash = factory.generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(hash);
    }*/

}
